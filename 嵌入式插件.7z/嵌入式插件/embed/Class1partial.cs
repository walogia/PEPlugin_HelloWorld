﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using PEPlugin;
using PEPlugin.Pmx;
using PEPlugin.View;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;

namespace embed
{
    partial class Class1
    {
    	private IPERunArgs args;
		private IPEPluginHost host;
		private IPEConnector connect;
		private IPXPmx PMX;
		public IPXPmxViewConnector PMXView;
		public IPEPMDViewConnector PMDView;
		public IPEBuilder builder;
		public IPEShortBuilder bd;
		
		//**************************************添加控件
        private TabPage tabPage;
        private Button button1;
		private GroupBox groupBox1;
	//********************添加结束**************
	     public void SetHostArgs(IPERunArgs args)
        {
            this.args = args;
        }
	        
        /// <summary>
        /// 寻找tabcontrol
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        private TabControl searchTabControl(Form form)
        {
            foreach (System.Windows.Forms.Control control in form.Controls)
            {
                if (control is TabControl)
                {

                    return (TabControl)control;

                }
            }
            return null;
        }

        private void addTabPage(Form form)
        {
            TabControl tabControl = searchTabControl(form);
            Console.WriteLine("control");

            // 
            // 创建新button1
            // 
            this.button1=new Button();
			this.button1.Location = new System.Drawing.Point(23, 27);
			this.button1.Name = "测试";
			this.button1.Size = new System.Drawing.Size(63, 31);
			this.button1.TabIndex = 0;
			this.button1.Text = "获取";
			this.button1.UseVisualStyleBackColor = true;
      		this.button1.Click += Button1Click;

            
            groupBox1=new GroupBox();
            groupBox1.Location = new System.Drawing.Point(6, 6);
			groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(177, 130);
			this.groupBox1.Text = "顶点";
            //
            //创建新tabpage
            //
            tabPage = new TabPage();
		    tabPage.Controls.Add(button1);//添加控件
            tabPage.Controls.Add(groupBox1);
            tabPage.Location = new System.Drawing.Point(4, 22);
            tabPage.Name = "tabPage2";
            tabPage.Padding = new System.Windows.Forms.Padding(3);
            tabPage.Size = new System.Drawing.Size(369, 227);
            tabPage.TabIndex = 1;
            tabPage.Text = "参数";
            //tabPage.UseVisualStyleBackColor = true;
           	tabPage.BackColor = System.Drawing.SystemColors.Control;
         //   tabPage.MouseDoubleClick += tabPage_MouseDoubleClick;


            tabControl.Controls.Add(tabPage);
        }
//***************************************
		void Button1Click(object sender, EventArgs e)
		{
			 this.InitializeValue();
			 
			 List<IPXVertex> list=GetSelectedVertexList();
			//获取选中顶点数
			int i=list.Count;
			 MessageBox.Show(i.ToString ());

			this.Update();
		}

//**************************************
		private void InitializeValue()
		{
			try
			{
				this.host = this.args.Host;;
				this.connect = this.host.Connector;
				this.PMX = this.connect.Pmx.GetCurrentState();
				this.PMDView = this.connect.View.PMDView;
				this.PMXView = this.connect.View.PmxView;
				this.builder = this.host.Builder;
				this.bd = this.host.Builder.SC;
			}
			catch
			{
				MessageBox.Show("值初始化失败");
			}
		}
		
			/// <summary>
	        /// モデル・画面を更新します。
	        /// </summary>
	        public void Update()
	        {
	            this.connect.Pmx.Update(this.PMX);
	            this.connect.Form.UpdateList(PEPlugin.Pmd.UpdateObject.All);
	            this.connect.View.PMDView.UpdateModel();
	            this.connect.View.PMDView.UpdateView();
	        }
		
        //*******************************函数开始*********************//
        
        /// <summary>
        /// 获取頂点Index
        /// </summary>
        /// <param name="Vertex"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        public int GetVertexIndex(IPXVertex Vertex, int e = 0)
        {
            for (int i = 0; i < this.PMX.Vertex.Count; i++)
            {
                if (this.PMX.Vertex[i] == Vertex)
                {
                    return i;
                }
            }
            if (e == 0)
            {
                return -1;
            }
            else
            {
                throw new System.Exception("Indexを取得できません。");
            }
        }
        /// <summary>
        /// PMXViewで選択した頂点のリストを返します。
        /// </summary>
        /// <returns></returns>
        public List<IPXVertex> GetSelectedVertexList()
        {
            int[] SelectedItem = this.PMDView.GetSelectedVertexIndices();
            if (SelectedItem.Length == 0)
            {
                throw new System.Exception("没有选中顶点");
            }
            List<IPXVertex> RetList = new List<IPXVertex>();
            for (int i = 0; i < SelectedItem.Length; i++)
            {
                RetList.Add(this.PMX.Vertex[SelectedItem[i]]);
            }
            return RetList;
        }
        
        //********************函数结束*******************************//
    }
}
